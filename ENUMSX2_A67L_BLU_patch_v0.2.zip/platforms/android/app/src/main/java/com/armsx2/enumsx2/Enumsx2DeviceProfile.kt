package com.armsx2.enumsx2

import android.os.Build

enum class Enumsx2Preset { PERFORMANCE, BALANCED, COMPATIBILITY }

data class Enumsx2DeviceProfile(
    val matched: Boolean,
    val preset: Enumsx2Preset,
    val gpuProfile: Int,
    val texturePreloading: Int,
    val accurateBlendingUnit: Int,
    val maxAnisotropy: Int,
    val hardwareDownloadMode: Int,
    val mtvu: Boolean,
    val eeCycleRate: Int,
    val eeCycleSkip: Int,
    val vsyncEnable: Boolean,
    val disableShaderCache: Boolean,
)

object Enumsx2DeviceProfiles {
    /**
     * Conservative ENUMSX2 defaults for the requested low/mid-range Android targets.
     * Values intentionally map to existing ARMSX2 Settings.kt fields:
     * gpuProfile 3 = PowerVR, texturePreloading 0/1/2 = Off/Partial/Full,
     * accurateBlendingUnit 0/1/... = Minimum/Basic/...,
     * hardwareDownloadMode 0 = accurate readbacks.
     *
     * Renderer selection and internal resolution are deliberately not forced here:
     * those need to respect runtime driver availability and per-game compatibility.
     */
    fun detect(): Enumsx2DeviceProfile {
        val haystack = listOf(
            Build.MANUFACTURER,
            Build.BRAND,
            Build.MODEL,
            Build.DEVICE,
            Build.PRODUCT,
            Build.HARDWARE,
        ).joinToString(" ").lowercase()

        val a67l = "a67l" in haystack
        val blu = "blu" in haystack && ("view" in haystack || "ultra" in haystack)
        val matched = a67l || blu

        return if (matched) {
            Enumsx2DeviceProfile(
                matched = true,
                preset = Enumsx2Preset.PERFORMANCE,
                gpuProfile = 3,
                texturePreloading = 1,
                accurateBlendingUnit = 0,
                maxAnisotropy = 0,
                hardwareDownloadMode = 0,
                mtvu = true,
                eeCycleRate = 0,
                eeCycleSkip = 0,
                vsyncEnable = false,
                disableShaderCache = false,
            )
        } else {
            Enumsx2DeviceProfile(
                matched = false,
                preset = Enumsx2Preset.BALANCED,
                gpuProfile = 0,
                texturePreloading = 2,
                accurateBlendingUnit = 1,
                maxAnisotropy = 0,
                hardwareDownloadMode = 0,
                mtvu = true,
                eeCycleRate = 0,
                eeCycleSkip = 0,
                vsyncEnable = false,
                disableShaderCache = false,
            )
        }
    }
}
