ENUMSX2 v0.2

Upload the contents of this archive into the root of branch:
enumsx2-a67l-blu-optimizations

Preserve folders when uploading.

New source file:
platforms/android/app/src/main/java/com/armsx2/enumsx2/Enumsx2DeviceProfile.kt

Documentation:
ENUMSX2_V02_INTEGRATION.md

This patch does not replace Settings.kt yet. It adds the verified device-profile source safely so the next patch can connect it to ConfigStore/default initialization without overwriting user preferences.
