# ENUMSX2 Patch 3

Patch 3 wires the A67L Gen2 / BLU View Ultra 5G profile into ARMSX2's real fresh-install configuration path.

## What becomes functional

- Detects the target devices from Android Build identifiers.
- Applies the profile only during ConfigStore's genuine fresh-install seed.
- Keeps ARM64 recompilers, fastmem and VU AOT enabled.
- Starts at native 1.0x internal resolution.
- Selects the existing PowerVR Android GPU profile.
- Uses partial texture preloading and disables anisotropic filtering/FXAA/shader chains by default.
- Keeps the shader cache enabled.
- Does not force unsafe clocks, disable accurate readbacks, or enable experimental VU pipeline hacks.
- Leaves existing users' saved settings untouched.

## Integration

Upload `EnumSX2DeviceProfile.kt` at its exact path, then make the small ConfigStore edit documented in `ENUMSX2_V03_CONFIGSTORE_PATCH.txt`.

This patch intentionally does not rename the Java package. Branding/package-id changes should be isolated from performance work so build failures are easier to diagnose.
