# ENUMSX2 Patch 4 - Sustained Mobile Policy

Patch 4 adds a conservative runtime-policy helper for the A67L Gen2 / BLU target class.

## What it does
- Detects A67L/BLU-style identifiers plus SC9863-family hardware as a fallback.
- Reuses ARMSX2 DeviceTier rather than replacing it.
- Keeps EE/IOP/VU recompilers, fastmem, VU AOT and safe NEON fusions enabled.
- Leaves aggressive/experimental VU timing shortcuts disabled.
- Uses Vulkan, native internal resolution and a 720p/1x output surface for sustained GPU load reduction.
- Selects the existing PowerVR profile (gpuProfile=3).
- Uses partial texture preloading and leaves the shader cache enabled.
- Enables render-pass coalescing for tiler GPUs.
- Keeps the two-frame GS queue for smoother sustained pacing.

## Important integration rule
Do NOT invoke `sustainedPreset()` on every app/game launch. That would overwrite user choices. Apply it only:
1. during ENUMSX2 fresh-install seeding for a detected target, or
2. from an explicit ENUMSX2/A67L preset button.

Patch 4 intentionally does not force Android sustained-performance mode or ADPF. ARMSX2 already exposes those as user choices; forcing them can reduce peak performance or behave differently across vendors.

## Suggested ConfigStore integration
Inside `seedFreshInstallDefaults`, build the normal fresh settings first, then conditionally transform them:

```kotlin
val base = freshInstallSettings(iopThreadDefaultOn, hasVulkan11())
val seeded = if (com.armsx2.enumsx2.Enumsx2RuntimePolicy.isPrimaryTarget())
    com.armsx2.enumsx2.Enumsx2RuntimePolicy.sustainedPreset(context, base)
else base
saveGlobal(seeded)
```

Replace the existing single `saveGlobal(freshInstallSettings(...))` call with the block above. This keeps existing installs untouched.
