package com.armsx2.enumsx2

import android.content.Context
import android.os.Build
import com.armsx2.DeviceTier
import com.armsx2.config.Settings

/** ENUMSX2 conservative runtime policy for the A67L Gen2 / BLU target class. */
object Enumsx2RuntimePolicy {
    private fun norm(s: String?) = s.orEmpty().lowercase().replace(" ", "")

    fun isPrimaryTarget(): Boolean {
        val model = norm(Build.MODEL)
        val device = norm(Build.DEVICE)
        val product = norm(Build.PRODUCT)
        val hardware = norm(Build.HARDWARE)
        val soc = norm(DeviceTier.socModel())
        return listOf(model, device, product).any {
            it.contains("a67lgen2") || it.contains("a67l") ||
            it.contains("bluviewultra5g") || it.contains("viewultra5g")
        } || hardware.contains("sc9863") || soc.contains("sc9863")
    }

    /** Apply only as a user-selected/fresh-install preset. Never call on every launch. */
    fun sustainedPreset(context: Context, base: Settings): Settings {
        if (!isPrimaryTarget() && !DeviceTier.isLowEnd(context)) return base
        return base.copy(
            cpu = base.cpu.copy(
                eeCycleRate = 0,
                eeCycleSkip = 0,
                mtvu = DeviceTier.mtvuDefault(),
                iopThread = DeviceTier.iopThreadDefault(DeviceTier.mtvuDefault()),
                recEE = true,
                recIOP = true,
                recVU0 = true,
                recVU1 = true,
                enableFastmem = true,
                vuAot = true,
                vuNeonFusions = true,
                vuDeferredWrites = false,
                vuSkipStallSim = false,
            ),
            output = base.output.copy(
                renderer = "vulkan",
                upscaleFloat = 1.0f,
                hwScaler = 1,
                screenResOverride = "1280x720",
            ),
            graphics = base.graphics.copy(
                accurateBlendingUnit = 1,
                texturePreloading = 1,
                maxAnisotropy = 0,
                fxaa = false,
                shaderChainEnabled = false,
                disableShaderCache = false,
                gpuProfile = 3,
            ),
            display = base.display.copy(
                hwRov = false,
                coalesceRenderPasses = true,
                gsBackThreadMode = 0,
            ),
            hwFixes = base.hwFixes.copy(
                vsyncQueueSize = 2,
            ),
        )
    }
}
